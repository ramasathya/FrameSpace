
document.addEventListener("DOMContentLoaded", () => {
    console.log("Interactive Portfolio is Ready!");
});
