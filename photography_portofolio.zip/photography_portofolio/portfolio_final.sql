
CREATE DATABASE IF NOT EXISTS portfolio_db;

USE portfolio_db;

-- Table for users
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL
);

-- Table for admins
CREATE TABLE IF NOT EXISTS admins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL
);

-- Table for orders
CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) NOT NULL,
    service VARCHAR(255) NOT NULL,
    details TEXT NOT NULL,
    FOREIGN KEY (username) REFERENCES users(username)
);

-- Table for gallery
CREATE TABLE IF NOT EXISTS gallery (
    id INT AUTO_INCREMENT PRIMARY KEY,
    image VARCHAR(255) NOT NULL,
    description TEXT NOT NULL
);

-- Insert default admin and user accounts
INSERT INTO admins (username, password) VALUES ('admin', 'admin123') ON DUPLICATE KEY UPDATE username=username;
INSERT INTO users (username, password) VALUES ('user1', 'user123') ON DUPLICATE KEY UPDATE username=username;

-- Insert sample data into gallery
INSERT INTO gallery (image, description) VALUES
('image1.jpg', 'Sample gallery image 1'),
('image2.jpg', 'Sample gallery image 2'),
('image3.jpg', 'Sample gallery image 3')
ON DUPLICATE KEY UPDATE image=image;

-- Insert sample orders
INSERT INTO orders (username, service, details) VALUES
('user1', 'Photography', 'Wedding photography service.'),
('user1', 'Editing', 'Photo editing for album creation.')
ON DUPLICATE KEY UPDATE username=username;
