
<?php
session_start();
if (!isset($_SESSION['username']) || $_SESSION['user_type'] != 'admin') {
    header("Location: login.php");
    exit();
}

include 'db_connection.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        .hover-zoom:hover { transform: scale(1.05); transition: 0.3s; }
        .magic-title { animation: fade-in 1.5s ease-in-out; }
        @keyframes fade-in {
            from { opacity: 0; }
            to { opacity: 1; }
        }
    </style>
</head>
<body class="bg-gray-100">
    <header class="bg-blue-500 text-white p-4 text-center">
        <h1 class="magic-title text-3xl font-bold">Admin Dashboard</h1>
        <a href="logout.php" class="absolute top-4 right-4 text-white hover:underline">Logout</a>
    </header>
    <main class="p-8 space-y-8">
        <section class="hover-zoom bg-white p-4 shadow rounded">
            <h2 class="text-xl font-bold">Manage Bookings</h2>
            <a href="manage_orders.php" class="text-blue-500 hover:underline">View All Bookings</a>
        </section>
        <section class="hover-zoom bg-white p-4 shadow rounded">
            <h2 class="text-xl font-bold">Manage Gallery</h2>
            <a href="manage_gallery.php" class="text-blue-500 hover:underline">View and Edit Gallery</a>
        </section>
    </main>
</body>
</html>
