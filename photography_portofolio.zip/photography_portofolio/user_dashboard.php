
<?php
session_start();
if (!isset($_SESSION['username']) || $_SESSION['user_type'] != 'user') {
    header("Location: login.php");
    exit();
}

include 'db_connection.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        .magic-text { animation: slide-in 2s ease-in-out infinite alternate; }
        @keyframes slide-in {
            from { transform: translateX(-100px); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
    </style>
</head>
<body class="bg-gray-100">
    <header class="bg-blue-500 text-white p-4 text-center">
        <h1 class="magic-text text-3xl font-bold">Welcome, <?php echo $_SESSION['username']; ?>!</h1>
    </header>
    <main class="p-8 max-w-lg mx-auto space-y-6">
        <h2 class="text-xl font-bold mb-4">Book a Service</h2>
        <form method="POST" action="order.php" class="space-y-4">
            <label class="block text-gray-700">Select Package:</label>
            <select name="package" class="w-full px-4 py-2 border rounded" required>
                <option value="Wedding Photography">Wedding Photography</option>
                <option value="Portrait Photography">Portrait Photography</option>
                <option value="Event Photography">Event Photography</option>
            </select>
            <label class="block text-gray-700">Additional Details:</label>
            <textarea name="details" rows="4" class="w-full px-4 py-2 border rounded"></textarea>
            <button type="submit" class="w-full bg-blue-500 text-white py-2 rounded hover:bg-blue-600">Confirm Booking</button>
        </form>
        <div class="text-center">
            <a href="logout.php" class="text-blue-500 hover:underline">Logout</a>
        </div>
    </main>
</body>
</html>
