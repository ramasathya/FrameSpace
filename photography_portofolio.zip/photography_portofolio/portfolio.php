
<?php
include 'db_connection.php';
$sql = "SELECT * FROM gallery";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portfolio</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        .carousel {
            display: flex;
            gap: 16px;
            overflow-x: scroll;
            scroll-behavior: smooth;
        }
        .carousel::-webkit-scrollbar {
            display: none;
        }
    </style>
</head>
<body class="bg-gray-100">
    <header class="bg-blue-500 text-white p-4 text-center">
        <h1>Portfolio</h1>
    </header>
    <main class="p-8">
        <h2 class="text-center text-2xl font-bold mb-8">Gallery</h2>
        <div class="carousel">
            <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<div class='bg-white rounded shadow-md p-4 w-64'>";
                    echo "<img src='" . $row['image'] . "' alt='" . $row['description'] . "' class='rounded'>";
                    echo "<p class='text-center mt-4'>" . $row['description'] . "</p>";
                    echo "</div>";
                }
            } else {
                echo "<p>No gallery items found.</p>";
            }
            ?>
        </div>
    
<div class="mt-4 text-center">
    <a href="index.html" class="text-black-500 hover:underline">Back to Home</a>
</div>
</main>
    <footer class="bg-blue-500 text-white text-center p-4">
        <p>&copy; 2025 Interactive Portfolio. All Rights Reserved.</p>
    </footer>
</body>
</html>
