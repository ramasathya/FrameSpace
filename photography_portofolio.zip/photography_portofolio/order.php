
<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

include 'db_connection.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_SESSION['username'];
    $package = $_POST['package'];
    $details = $_POST['details'];

    $sql = "INSERT INTO bookings (username, package, details) VALUES ('$username', '$package', '$details')";

    if ($conn->query($sql) === TRUE) {
        echo "Booking confirmed!";
    } else {
        echo "Error: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book a Service</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">
    <header class="bg-blue-500 text-white p-4 text-center">
        <h1>Book a Service</h1>
    </header>
    <main class="p-8 max-w-lg mx-auto bg-white shadow rounded">
        <form method="POST" class="space-y-4">
            <label class="block text-gray-700">Package:</label>
            <select name="package" class="w-full px-4 py-2 border rounded" required>
                <option value="Wedding Photography">Wedding Photography</option>
                <option value="Portrait Photography">Portrait Photography</option>
                <option value="Event Photography">Event Photography</option>
            </select>
            <label class="block text-gray-700">Details:</label>
            <textarea name="details" rows="4" class="w-full px-4 py-2 border rounded" required></textarea>
            <button type="submit" class="w-full bg-blue-500 text-white py-2 rounded hover:bg-blue-600">Confirm Booking</button>
        </form>
        <?php echo '$back_to_home_button'; ?>
    </main>
</body>
</html>
