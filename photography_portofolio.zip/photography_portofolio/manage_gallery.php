
<?php
include 'db_connection.php';
session_start();

if (!isset($_SESSION['username']) || $_SESSION['user_type'] != 'admin') {
    header("Location: login.php");
    exit();
}

// Add new gallery image
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $description = $_POST['description'];
    $image = $_POST['image'];

    $sql = "INSERT INTO gallery (image, description) VALUES ('$image', '$description')";
    if ($conn->query($sql) === TRUE) {
        echo "New gallery item added successfully!";
    } else {
        echo "Error: " . $conn->error;
    }
}

// Fetch gallery items
$sql = "SELECT * FROM gallery";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Gallery</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h1>Manage Gallery</h1>
    <form method="POST">
        <label for="image">Image URL:</label>
        <input type="text" id="image" name="image" required>
        <label for="description">Description:</label>
        <input type="text" id="description" name="description" required>
        <button type="submit">Add Image</button>
    </form>

    <h2>Gallery Items</h2>
    <ul>
        <?php
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<li><img src='" . $row['image'] . "' alt='" . $row['description'] . "'>" . $row['description'] . "</li>";
            }
        } else {
            echo "<li>No items found</li>";
        }
        ?>
    </ul>

    <a href="dashboard.php">Back to Dashboard</a>
</body>
</html>
